# Dataset Card Reuse Reference — Agent Entrypoint

Show agents how to publish dataset cards with provenance, licensing, freshness, evaluation notes, and reuse boundaries.

## Primary task

Given this AgentPress bundle, verify dataset provenance, cite source claims, and produce a safe reuse checklist.

## Input contract

Required: subject, hypothesis

Optional: source_url, time_horizon, context

## Expected output schema

```json
{
  "decision": "survive | delete | needs_more_diligence",
  "reasons": [
    "string"
  ],
  "verified_sources": [
    "string"
  ],
  "missing_checks": [
    "string"
  ],
  "confidence": "low | medium | high",
  "disclaimer": "Follow the allowed-actions boundary and verify source claims before external use."
}
```

## Citation policy

Cite source evidence from `source-map.json` and canonical assets. Do not cite unsupported claims.

## Allowed actions

Read, summarize, cite, transform, benchmark, open an issue, or create a pull request. Do not recommend trades or access private data.

## Non-goals

- Do not hallucinate sources.
- Do not hide uncertainty.
- Do not turn reference guidance into external writes or production changes.

## Citation / disclaimer

Follow the allowed-actions boundary and verify source claims before external use. Canonical URL: https://example.com/dataset-card-reuse-reference/
