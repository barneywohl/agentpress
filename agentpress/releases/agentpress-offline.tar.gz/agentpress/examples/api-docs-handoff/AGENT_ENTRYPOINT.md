# API Docs Handoff Reference — Agent Entrypoint

Show agents how to publish API documentation that can be discovered, cited, validated, and safely reused.

## Primary task

Given this AgentPress bundle, identify endpoints, source boundaries, allowed actions, and missing checks before generating API integration guidance.

## Input contract

Required: subject, hypothesis

Optional: source_url, time_horizon, context

## Expected output schema

```json
{
  "decision": "survive | delete | needs_more_diligence",
  "reasons": [
    "string"
  ],
  "verified_sources": [
    "string"
  ],
  "missing_checks": [
    "string"
  ],
  "confidence": "low | medium | high",
  "disclaimer": "Follow the allowed-actions boundary and verify source claims before external use."
}
```

## Citation policy

Cite source evidence from `source-map.json` and canonical assets. Do not cite unsupported claims.

## Allowed actions

Read, summarize, cite, transform, benchmark, open an issue, or create a pull request. Do not recommend trades or access private data.

## Non-goals

- Do not hallucinate sources.
- Do not hide uncertainty.
- Do not turn reference guidance into external writes or production changes.

## Citation / disclaimer

Follow the allowed-actions boundary and verify source claims before external use. Canonical URL: https://example.com/api-docs-handoff-reference/
